package com.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Bulletine;
import com.model.Comment;
@Repository
public class CommentDAOImpl implements CommentDAO 
{
	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public List<Comment> getList() {
		
		Session session = sessionFactory.openSession();
		@SuppressWarnings("unchecked")
		List<Comment> comList = session.createQuery("from Comment").list();
		session.close();
		return comList;
	}

	@Override
	public void addComment(Comment com) {
		Session session=sessionFactory.openSession();
		session.saveOrUpdate(com);
		session.flush();
	}

}
